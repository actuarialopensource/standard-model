from modelx.serialize.jsonvalues import *

_formula = lambda point_id: None

_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def model_point():
    return model_point_data.loc[point_id]


def sum_assured(): return model_point_data["sum_assured"]


def age_at_entry(): return model_point_data["age_at_entry"]


def term_y(): return model_point_data["term_y"]


def smoker_status(): return model_point_data["smoker_status"]


def shape(): return model_point_data["shape"]


def annual_premium(): return model_point_data["annual_premium"]


def init_pols_if(): return 1


def extra_mortality(): return (smoker_status() == "S").astype(int)


def sex(): return model_point_data["sex"]


def proj_len(): return 12 * term_y() + 1


def cost_inflation_pa(): return 0.02


def initial_expense(): return pd.Series(500, index=model_point_data.index)


def expense_pp(): return 10


def lapse_rate_pa(): return 0.1


def disc_rate_monthly():
    return np.array(list((1 + disc_rate_annual[t//12])**(1/12) - 1 for t in range(max_proj_len())))


def disc_factors():
    return np.array(list((1 + disc_rate_monthly()[t])**(-t) for t in range(max_proj_len())))


def net_cf(t):
    return premiums(t) - claims(t) - expenses(t)


def premium_pp(t):
    """monthly premium"""
    return annual_premium / 12


def claim_pp(t):
    # if t == 0:
    #     return sum_assured()
    # elif t > term_y() * 12:
    #     return 0
    # elif shape == "level":
    #     return sum_assured()
    # elif shape == "decreasing":
    #     r = (1+0.07)**(1/12)-1
    #     S = sum_assured()
    #     T = term_y() * 12
    #     outstanding = S * ((1+r)**T - (1+r)**t)/((1+r)**T - 1)
    #     return outstanding
    # else:
    #     raise ValueError("Parameter 'shape' must be 'level' or 'decreasing'")


    if t == 0:
        return sum_assured()
    elif t >= max_proj_len():
        raise KeyError("t out of range")
    else:
        r = (1+0.07)**(1/12)-1
        S = sum_assured()
        T = term_y() * 12
        outstanding = S * ((1+r)**T - (1+r)**t)/((1+r)**T - 1)

        level = (shape() == "level").astype(int)  * sum_assured()
        decr = (shape() == "decreasing").astype(int) * (t <= term_y() * 12).astype(int) * outstanding

        return level + decr


def inflation_factor(t):
    """annual"""
    return (1 + cost_inflation_pa())**(t//12)


def premiums(t):
    return premium_pp(t) * num_pols_if(t)


def duration(t):
    """duration in force in years"""
    return t//12


def claims(t):
    return claim_pp(t) * num_deaths(t)


def expenses(t):
    if t == 0:
        return initial_expense()
    else:
        return num_pols_if(t) * expense_pp()/12 * inflation_factor(t)


def num_pols_if(t):
    """number of policies in force"""
    # if t==0:
    #     return init_pols_if()
    # elif t > term_y() * 12:
    #     return 0
    # else:
    #     return num_pols_if(t-1) - num_exits(t-1) - num_deaths(t-1)

    if t==0:
        return init_pols_if()
    elif t < max_proj_len():

        return (t < proj_len()) * (num_pols_if(t-1) - num_exits(t-1) - num_deaths(t-1))
        # raise KeyError("t out of range")
    else:
        # return num_pols_if(t-1) - num_exits(t-1) - num_deaths(t-1)
        raise KeyError("t out of range")


def num_exits(t):
    """exits occurring at time t"""
    return num_pols_if(t) * (1-(1 - lapse_rate_pa())**(1/12))


def num_deaths(t):
    """deaths occurring at time t"""
    return num_pols_if(t) * q_x_12(t)


def age(t):
    return age_at_entry + t//12


def q_x_12(t):
    return 1-(1- q_x_rated(t))**(1/12)


def qx_non_smoker(t):
    """non-smoker mortality"""
    return mort_qx_non_smoker[str(min(5, duration(t)))][age(t)]


def qx_smoker(t):
    """smoker mortality"""
    return mort_qx_smoker[str(min(5, duration(t)))][age(t)]


def q_x(t):
    # if smoker_status == "N":
    #     return qx_non_smoker(t)
    # elif smoker_status == "S":
    #     return qx_smoker(t)
    result = np.where(smoker_status() == "N", qx_non_smoker(t), qx_smoker(t))
    return pd.Series(result, index=smoker_status().index)


def q_x_rated(t):
    return np.maximum(0, np.minimum(1 , q_x(t) * (1 + extra_mortality()) ) )


def commission(t): return 0


def npv_claims():
    # return sum(list(claims(t) for t in range(proj_len())) * disc_factors()[:proj_len()])

    cl = np.array(list(claims(t) for t in range(max_proj_len()))).transpose()

    return cl @ disc_factors()[:max_proj_len()]


def npv_expenses():
    # return sum(list(expenses(t) for t in range(proj_len())) * disc_factors()[:proj_len()])

    result = np.array(list(expenses(t) for t in range(max_proj_len()))).transpose()

    return result @ disc_factors()[:max_proj_len()]


def npv_commission():
    # return sum(list(commission(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


    result = np.array(list(commission(t) for t in range(max_proj_len()))).transpose()

    return result @ disc_factors()[:max_proj_len()]


def npv_premiums():
    # return sum(list(premiums(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


    result = np.array(list(premiums(t) for t in range(max_proj_len()))).transpose()

    return result @ disc_factors()[:max_proj_len()]


def annual_risk_premium():
    return (npv_claims() + npv_expenses() + npv_commission()) / npv_premiums()


def monthly_risk_premium():
    return np.around(annual_risk_premium() / 12, 2)


max_proj_len = lambda: max(proj_len())

def temp(t):
    r = (1+0.07)**(1/12)-1
    T = term_y() * 12
    return ((1+r)**T - (1+r)**t)/((1+r)**T - 1)


# ---------------------------------------------------------------------------
# References

mort_qx_smoker = ("DataClient", 2499959680072)

mort_qx_non_smoker = ("DataClient", 2499959680072)

disc_rate_annual = ("DataClient", 2499957728776)

model_point_data = ("DataClient", 2499959572936)

point_id = 1